from flask import Flask, render_template, request, session,redirect
from tkinter import *
import pandas as pd
import csv
from tabulate import tabulate
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from datetime import datetime
from flask_mail import Mail
import json
import math
import os
local_server=True
app = Flask(__name__)
app.secret_key = 'super-secret-key'


@app.route('/')
def hello():
    return render_template('home.html')

@app.route('/test')
def test():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/get_hosp', methods=['POST'])
def get_hosp():
    window = Tk()
    window.after(500, lambda: window.destroy())  # Destroy the widget after 30 seconds
    window.title("main")
    data = pd.read_csv(r"C:\Users\ABHISHEK MOHARIR\Desktop\hospital_directory.csv")

    dict = data.to_dict()
    ft = tabulate(data.head(), headers='keys', tablefmt='simple', colalign=("right",))
    print(ft)
    lable1 = Label(text=ft)
    lable1.pack()

    list = []

    input_pin = request.form['pin']

    lable0 = Label(text="Result::", font=("Arial", 40, "bold"))
    lable0.pack()

    with open(r"C:\Users\ABHISHEK MOHARIR\Desktop\hospital_directory.csv", "r") as file:
        d_reader = csv.DictReader(file)
        for i in d_reader:

            # print("Found Entry :")
            if i["Pincode"] == input_pin:
                list.append(i)
                # print(i)
    # tab=pd.DataFrame(list,columns=["Hospital_Name","Location","State","Telephone","Address_Original_First_Line"])
    tab = tabulate(list, headers='keys', tablefmt='html', colalign=("center",))

    print(tab)

    lable2 = Label(text=tab)
    lable2.pack()
    window.mainloop()
    return tab

if __name__ == '__main__':
    app.run(debug=True)
